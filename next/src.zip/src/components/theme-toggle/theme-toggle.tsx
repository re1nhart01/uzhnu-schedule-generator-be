"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

export function ThemeToggle() {
  const { setTheme, theme } = useTheme();

  const handleChangeTheme = () => {
    if (!theme) {
      setTheme("light");
      return;
    }
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    console.log("Switched to", newTheme);
  };

  return (
    <Button variant="outline" size="icon" onClick={handleChangeTheme}>
      <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}
